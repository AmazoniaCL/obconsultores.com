    <script src="{{ asset('assets/javascript/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/javascript/plugins.js') }}"></script>
    <script src="{{ asset('assets/javascript/jquery-ui.js') }}"></script>
    <script src="{{ asset('assets/javascript/gmap3.min.js') }}"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCo_pcAdFNbTDCAvMwAD19oRTuEmb9M50c"></script>
    <script src="{{ asset('assets/javascript/jquery-isotope.js') }}"></script>
    <script src="{{ asset('assets/javascript/equalize.min.js') }}"></script>
    <script src="{{ asset('assets/javascript/jquery-countTo.js') }}"></script>
    <script src="{{ asset('assets/javascript/flex-slider.min.js') }}"></script>
    <script src="{{ asset('assets/javascript/main.js') }}"></script>

    <!-- slider -->
    <script src="{{ asset('assets/rev-slider/js/jquery.themepunch.tools.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/jquery.themepunch.revolution.min.js') }}"></script>
    <script src="{{ asset('assets/javascript/rev-slider.js') }}"></script>

    <!-- Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading -->
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.actions.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.carousel.min.j') }}s"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.kenburn.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.layeranimation.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.migration.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.navigation.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.parallax.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.slideanims.min.js') }}"></script>
    <script src="{{ asset('assets/rev-slider/js/extensions/extensionsrevolution.extension.video.min.js') }}"></script>

    @yield('MyScripts')