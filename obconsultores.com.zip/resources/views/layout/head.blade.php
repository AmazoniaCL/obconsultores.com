<head>
    <meta charset="UTF-8">
    <title>ObConsultores</title>

    <!-- Mobile Specific Metas-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- Bootstrap-->
    <link rel="stylesheet" href="{{ asset('assets/stylesheet/bootstrap.css') }}">

    <!-- Template Style-->
    <link rel="stylesheet" href="{{ asset('assets/stylesheet/all.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/stylesheet/animate.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/stylesheet/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/stylesheet/shortcodes.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/stylesheet/responsive.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/stylesheet/flexslider.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/rev-slider/css/layers.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/rev-slider/css/navigation.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/rev-slider/css/settings.css') }}">

    <link href="{{ asset('assets/icon/favicon.ico') }}" rel="shortcut icon">

    {{-- CSRF Token --}}
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>